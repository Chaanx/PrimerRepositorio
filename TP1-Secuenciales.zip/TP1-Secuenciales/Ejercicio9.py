temperatura = int(input("Ingrese la temperatura en grados celsius: "))

print(f"La temperatura en grados fahrenheit es de: ", 9/5 * temperatura + 32)
