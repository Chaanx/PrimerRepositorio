numero_1 = int(input("ingrese un numero positivo: "))
numero_2 = int(input("ingrese otro numero positivo: "))

print(f"La suma de ", numero_1, "y", numero_2, "da como resultado: ", numero_1 + numero_2)
print(f"La resta de ", numero_1, "y", numero_2, "da como resultado: ", numero_1 - numero_2)
print(f"La multiplicacion entre ", numero_1, "y", numero_2, "da como resultado: ", numero_1 * numero_2)
print(f"La division entre ", numero_1, "y", numero_2, "da como resultado: ", numero_1 / numero_2)