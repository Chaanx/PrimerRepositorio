segundos = int(input("Ingrese una cantidad de segundos: "))
print(F"Los segundos ingresados equivalen aun total de ", segundos / 3600, "horas")
      