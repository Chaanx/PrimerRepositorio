radio = int(input("Ingrese el radio: "))
pi = 3.14159
print("El area del circulo es: ", pi * radio**2)
print("El perimetro del circulo es: ", 2 * pi * radio)
                  