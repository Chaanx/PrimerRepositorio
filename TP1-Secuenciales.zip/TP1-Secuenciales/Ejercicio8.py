peso = int(input("Ingrese su peso: "))
altura = float(input("Ingrese su altura: "))

print(f"Su indice de masa corporal es de: ", peso / (altura **2))