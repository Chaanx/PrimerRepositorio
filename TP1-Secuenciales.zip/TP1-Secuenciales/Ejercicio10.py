numero_1 = int(input("Ingrese el primer valor: "))
numero_2 = int(input("Ingrese el segundo valor: "))
numero_3 = int(input("Ingrese el tercer valor: "))
 
print(f"El promedio entre los tres valores es de : ", (numero_1 + numero_2 + numero_3) / 3 ) 